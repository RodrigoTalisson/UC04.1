import { AlunoModel } from "../models/aluno/AlunoModel.js";

export class AlunoController {


  static listarAlunos(req, res) {
    return res.status(200).json(AlunoModel.listarTodos());
  }


  static buscarPorId(req, res) {
    const aluno = AlunoModel.buscarPorId(req.params.id);

    if (!aluno) {
      return res.status(404).json({ msg: "Aluno não encontrado" });
    }

    return res.status(200).json(aluno);
  }

 
  static criarAluno(req, res) {
    const { nome, idade, curso, matricula } = req.body;

    if (!nome || !idade || !curso || !matricula) {
      return res.status(400).json({ msg: "Todos os campos são obrigatórios" });
    }

    if (idade < 16) {
      return res.status(400).json({ msg: "Idade mínima é 16 anos" });
    }

    if (AlunoModel.buscarPorMatricula(matricula)) {
      return res.status(400).json({ msg: "Matrícula já existe" });
    }

    const aluno = AlunoModel.criar({ nome, idade, curso, matricula });

    return res.status(201).json({
      msg: "Aluno criado com sucesso",
      aluno
    });
  }


  static atualizarAluno(req, res) {
    const { id } = req.params;
    const { nome, idade, curso, matricula } = req.body;

    const aluno = AlunoModel.buscarPorId(id);

    if (!aluno) {
      return res.status(404).json({ msg: "Aluno não encontrado" });
    }

    if (idade < 16) {
      return res.status(400).json({ msg: "Idade mínima é 16 anos" });
    }

    const matriculaExiste = AlunoModel.buscarPorMatricula(matricula);

    if (matriculaExiste && matriculaExiste.id != id) {
      return res.status(400).json({ msg: "Matrícula já usada por outro aluno" });
    }

    aluno.nome = nome;
    aluno.idade = idade;
    aluno.curso = curso;
    aluno.matricula = matricula;

    return res.status(200).json({
      msg: "Aluno atualizado com sucesso",
      aluno
    });
  }


  static deletarAluno(req, res) {
    const aluno = AlunoModel.deletar(req.params.id);

    if (!aluno) {
      return res.status(404).json({ msg: "Aluno não encontrado" });
    }

    return res.status(200).json({
      msg: "Aluno removido com sucesso",
      aluno
    });
  }
}
