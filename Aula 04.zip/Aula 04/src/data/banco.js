export const alunos = [
  {
    id: 1,
    nome: "Rodrigo Talisson",
    idade: 16,
    curso: "Informática",
    matricula: "MAT001"
  },
  {
    id: 2,
    nome: "Andre",
    idade: 22,
    curso: "Informática",
    matricula: "MAT002"
  },
  {
    id: 3,
    nome: "Denis",
    idade: 22,
    curso: "Administração",
    matricula: "MAT003"
  },
    {
    id: 4,
    nome: "Rodrigo Silva",
    idade: 16,
    curso: "Informática",
    matricula: "MAT004"
  },
  {
    id: 5,
    nome: "Vinicius",
    idade: 22,
    curso: "Informática",
    matricula: "MAT005"
  },
  {
    id: 6,
    nome: "Wesley",
    idade: 22,
    curso: "Administração",
    matricula: "MAT006"
  },
    {
    id: 7,
    nome: "Itamar",
    idade: 16,
    curso: "Informática",
    matricula: "MAT007"
  },
  {
    id: 8,
    nome: "Paulo",
    idade: 22,
    curso: "Informática",
    matricula: "MAT008"
  },
  {
    id: 9,
    nome: "Davi",
    idade: 22,
    curso: "Administração",
    matricula: "MAT009"
  },
    {
    id: 10,
    nome: "Calebe",
    idade: 16,
    curso: "Informática",
    matricula: "MAT010"
  },
  {
    id: 11,
    nome: "Everton",
    idade: 22,
    curso: "Informática",
    matricula: "MAT011"
  },
  {
    id: 12,
    nome: "Bruno",
    idade: 22,
    curso: "Administração",
    matricula: "MAT012"
  },
    {
    id: 13,
    nome: "Guilherme",
    idade: 16,
    curso: "Informática",
    matricula: "MAT013"
  }

];
