import { Router } from "express";
import { AlunoController } from "../controllers/AlunoController.js";

const router = Router();


router.get("/", AlunoController.listarAlunos);

router.get("/:id", AlunoController.buscarPorId);


router.post("/", AlunoController.criarAluno);


router.put("/:id", AlunoController.atualizarAluno);


router.delete("/:id", AlunoController.deletarAluno);

export default router;

